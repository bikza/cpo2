var some = new Array(); 
some[0] = '1'; 
some[1] = 2; 
console.log(some[0]); 
var array = new Array(1, 5, 2); 



var elements = new Array(23, 6, 0, true, "Первый"); 
console.log(elements.length);



var x = new Array(new Array(0, 34, 2), new Array(3, 4, 5)); 
console.log(x[0][1]); 
var symbols = new Array(new Array(), new Array()); 
symbols [0][1] = 'A';



var arr = [5, true, "stroka", 5.7, 0, -100]; 
arr[3] = "word"; 
console.log(arr.length); 
 
var matrix = [ 
  [4, 6, 8], ["stroka", 5.7], [0, -100] 
]; 
matrix[1][0] = 90; 
console.log(matrix);

